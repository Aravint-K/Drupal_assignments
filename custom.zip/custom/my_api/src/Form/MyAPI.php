<?php

namespace Drupal\my_api\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;

class MyAPI extends FormBase{

    public function getFormId(){
        return 'movie_api_config_page';
    }

    public function buildForm(array $form ,FormStateInterface $form_state){

        $form=[];

        $form['brand_name']=[
            '#type'=>'textfield',
            '#title'=> $this->t('Brand Name'),
            //'#description'=>$this->t('This is the API Base Url'),
            '#required'=>TRUE,
            '#default_value'=>isset($record['brand_name']) ? $record['brand_name'] : '',
        ];

        $form['model_name']=[
            '#type'=>'textfield',
            '#title'=>$this->t('Model Name'),
            //'#description'=>$this->t('This is the API key'),
            //'#required'=>TRUE,
            '#default_value'=>isset($record['model_name']) ? $record['model_name'] : '',
        ];


        $form['actions']['submit']=[
            '#type'=>'submit',
            '#value'=>$this->t('Save'),
            '#button_type'=>'primary'
        ];

        return $form;
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {

        
        print_r("CHECKING --");

        $brand_name = $form_state->getValue('brand_name');
        $model_name = $form_state->getValue('model_name');

        // To set a session variable:
        $_SESSION['brand_name'] = $brand_name;
        $_SESSION['model_name'] = $model_name;


         $conn = Database::getConnection();

        $flag = false;
        
        if($brand_name=='Samsung'){
          $flag = true;
        }

          if ($flag==true) {
          } else {
                $conn->insert('brands')
                  ->fields([
                    'brand_name' => $brand_name,
                    'model_name' => $model_name,
                  ])                
                  ->execute();
                $messenger = \Drupal::service('messenger');
                $messenger->addMessage($this->t('Mobile data added successfully'));
          }     
    
        $form_state->setRedirect('my_api.catfact');
      }
    
}