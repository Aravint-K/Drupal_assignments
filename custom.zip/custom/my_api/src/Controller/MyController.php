<?php

 

namespace Drupal\my_api\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Component\Serialization\Json;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use GuzzleHttp\ClientInterface;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;

class MyController extends ControllerBase{

    public static function create(ContainerInterface $container) {
        return new static(
          $container->get('http_client')
        );
    }

    public function __construct(ClientInterface $http_client) {
        $this->httpClient = $http_client;
    }

    protected $httpClient;

    public function getPhone() {

        // $barndNameSession = \Drupal::session()->get('brand_name');
        // $ModelNameSession = \Drupal::session()->get('model_name');

        // To get a session variable:
        $barndNameSession = $_SESSION['brand_name'];
        $ModelNameSession = $_SESSION['model_name'];

        //$values = $form_state->getValues();
        $conn = Database::getConnection();
        $subQuery = $conn->select('brands', 's');
        $subQuery->fields('s');
        $subQuery->condition('brand_name',$barndNameSession);
        $subResult = $subQuery->execute()->fetchAll();
 
        $brandName='';
        $modelName='';

        if(!empty($subResult) && $subResult !== null){
          foreach ($subResult as $row) {
            $brandName = $row->brand_name;
            $modelName = $row->model_name;
         }
        }

       if ($modelName === null || $modelName === "") {
        $phoneData = [
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 12',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 13',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 12 pro max',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'ipad',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 11',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 14 pro',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone 12 mini',
            'display_type' => 'OLED',
          ],
          [
            'brand_name' => 'Apple',
            'model_name' => 'iPhone x',
            'display_type' => 'OLED',
          ],
          // Add more phone data sets as needed
        ];
        // Pass the data to the template for rendering.
        return [
          '#theme' => 'my-api',
          '#content' => $phoneData,
        ];
        print_r($phoneData);
       }
       else{   

        $headers = [
          'X-RapidAPI-Key' => '289e9a0313mshd0f71817efae444p1a8cf6jsn9343b278442c',
          'X-RapidAPI-Host' => 'mobile-phone-specs-database.p.rapidapi.com',
        ];

        $samsung=$brandName;

        $urlModels = 'https://mobile-phone-specs-database.p.rapidapi.com/gsm/get-models-by-brandname/'."".$samsung;
        $query = ['phoneid' => '1859'];

          $responseModels = $this->httpClient->request('GET', $urlModels, [

            'headers' => $headers,
          ]);

            $dataModels = $responseModels->getBody()->getContents();
            $contentModels = json::decode($dataModels);
            $modelValue = array_slice($contentModels, 0, 5);
            $urlSpecs = 'https://mobile-phone-specs-database.p.rapidapi.com/gsm/get-specifications-by-brandname-modelname/'."".$samsung."/".$modelName;
            $responseSpecs = $this->httpClient->request('GET', $urlSpecs, [
              'headers' => $headers,
              //'query' => $query,
            ]);
            $dataSpecs = $responseSpecs->getBody()->getContents();
            $contentSpecs = json::decode($dataSpecs);
            //$specs = array_slice($contentSpecs, 0, 5);
            $displayType=$contentSpecs['gsmDisplayDetails']['displayType'];

            $phoneData=[];
            $phoneData['model_name']=$modelName;
            $phoneData['brand_name']=$samsung;
            $phoneData['display_type']=$displayType;
            return [
              '#theme' =>'my-api',
              '#content' => $phoneData,
           ];
       }
      }
}