<?php

namespace Drupal\login\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Messenger;
use Drupal\Core\Link;
use Drupal\Component\Serialization\Json;

class LoginForm extends FormBase {

  public function getFormId() {
    return 'login_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $conn = Database::getConnection();
    $record = [];

    // if ($id) {
    //   $query = $conn->select('login', 's')
    //     ->condition('id', $id)
    //     ->fields('s');
    //   $record = $query->execute()->fetchAssoc();
    // }

    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#required' => TRUE,
      '#default_value' => isset($record['name']) ? $record['name'] : '',
    ];
    $form['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
      '#required' => TRUE,
      '#default_value' => isset($record['password']) ? $record['password'] : '',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save'),
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Add validation logic here if needed.
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $conn = Database::getConnection();

    $name = $form_state->getValue('name');

    // $subQuery = $conn->select('login', 's');
    // $subQuery->fields('s', ['name']);
    // //$subQuery->fields('s');
    // //$subQuery->condition('s.name', $name);
    // $subResult = $subQuery->execute()->fetchAll();

    $flag= false;

    if($name == 'admin' || $name == 'arvi'){
      $flag= true;
    }

    if($flag == true){
      $messenger = \Drupal::service('messenger');
      $messenger->addMessage($this->t('Logged in successfully'));
      $form_state->setRedirect('my_api.movie_api_config_page');
    }else{
      $messenger = \Drupal::service('messenger');
      $messenger->addWarning($this->t('Wrong credentials'));
    }
  }
}
